-- create email_list
CREATE TABLE email_list (
    id INT PRIMARY KEY,
    email VARCHAR NOT NULL
);

-- insert sample input into the email_list table
INSERT INTO email_list (ID, email)
VALUES
  (1, 'abc@gmail.com'),
  (2, 'def@gmail.com'),
  (3, 'abc@yahoo.com'),
  (4, 'abc@gmail.com'),
  (5, 'def@gmail.com'),
  (6, 'def@gmail.com'),
  (7, 'abc@bing.com');

-- syntax for sample output
SELECT email
FROM email_list
GROUP BY email
HAVING COUNT(email) > 1;
