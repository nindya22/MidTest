-- create input table
CREATE TABLE input_table (
    id INT PRIMARY KEY,
    num INT NOT NULL
);

-- Inserts input samples into the input_table table
INSERT INTO input_table (id, num)
VALUES
  (1, 1),
  (2, 2),
  (3, 2),
  (4, 2),
  (5, 2),
  (6, 1),
  (7, 1),
  (8, 1),
  (9, 1);

-- syntax for sample output
WITH SampleOutput AS (
  SELECT
    num,
    LAG(num) OVER (ORDER BY id) AS prev_num,
    LAG(num, 2) OVER (ORDER BY id) AS prev_num_2
  FROM input_table
)

SELECT DISTINCT num
FROM SampleOutput
WHERE num = prev_num AND num = prev_num_2
ORDER BY num;
